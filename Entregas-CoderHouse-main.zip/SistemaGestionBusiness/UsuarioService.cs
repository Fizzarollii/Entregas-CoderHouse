﻿using NicolasCanavese;
using SistemaGestionEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionBussiness
{
    public class UsuarioService
    {
        public int Id { get; set; }
        public static List<Usuario> GetUsuarios()
        {
            return UsuarioData.ListarUsuarios();
        }
        public static bool EliminarUsuario(int Id)
        {
            return true;
        }

        public static void CrearUsuario(Usuario usuario)
        {
            UsuarioData.CrearUsuario(usuario);
        }

        public static void ModificarUsuario(Usuario usuario)
        {
            UsuarioData.ModificarUsuario(usuario);
        }

        public static Usuario GetUsuarioById(int id)
        {
            return UsuarioData.ObtenerUsuario(id);
        }
    }
}