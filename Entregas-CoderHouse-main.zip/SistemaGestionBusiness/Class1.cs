﻿namespace SistemaGestionBusiness
{
    public class Class1
    {

    }
}
