﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SistemaGestionBussiness;
using SistemaGestionEntities;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductoController : ControllerBase
    {
        [HttpGet(Name = "GetProducto")]
        public IEnumerable<Producto> Productos()
        {
            return ProductoService.GetProductos();
        }
        [HttpGet("{id}")]
        public IActionResult GetProductoById (int id)
        {
            Producto producto = ProductoService.GetProductById(id);
            return Ok(producto);
        }
    }
}
